<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FactureDAO extends CI_Model {

		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function getFactureEnCours(){
			$sql = "select idfact,dateD,dateF,numFact,totalAvantRemise,remiseFact,remiseClient,totalApaye,payee,arendre from facture where arendre>0";
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		public function insererFacture($idkil,$totalAvantRemise,$dateF,$remiseFact,$remiseClient,$totalApaye,$payee,$arendre){

			//getTotal Facture client pour construire numFact="F"+idClient+"/"+factnumero"
				$sql = "select count(idfact) from facture where idclient like '".$idkil."'";
				//echo($sql);
				$result = $this->db->query($sql);
				$retour = $result->row_array();
				return $retour;
			//construire num fact
				$numFact = "F".$idkil."/".$retour;

			$sql = "INSERT INTO `basefacturation`.`facture` (`IDFACT`, `IDCLIENT`, `DATED`, `NUMFACT`, `TOTALAVANTREMISE`, `DATEF`, `REMISEFACTURE`, `REMISECLIENT`, `TOTALAPAYE`, `PAYEE`, `ARENDRE`) VALUES ('', '".$idkil."', now(), '".$numFact."', '".$totalAvantRemise."', '".$dateF."', '".$remiseFact."', '".$remiseClient."', '".$totalApaye."', '".$payee."', '".$arendre."');";
			//echo $sql;
			$this->db->query($sql);

			

			$this->db->close();
		}
		
