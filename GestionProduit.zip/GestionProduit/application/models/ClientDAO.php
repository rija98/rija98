<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClientDAO extends CI_Model {

		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function getMember($login,$mdp){
			$sql = "select idclient,nom,numclient from Client where nom ='".$login."' and pass='".$mdp."'";
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->row_array();
			$this->db->close();
			return $retour;

		}

		public function getAdmin($login,$mdp){
			$sql = "select idclient,nom from Admin where nom ='".$login."' and pass='".$mdp."'";
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;

		} 

	}
