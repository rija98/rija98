<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProduitDAO extends CI_Model {

		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function getProduits($cat,$sCat,$ssCat,$feuil,$limit,$offset){

			$condition="";
			if($cat!="%%"){
				$condition =$condition." and idcat like '".$cat."'";
			}
			if($sCat!="%%"){
				$condition = $condition." and idscat like '".$sCat."'";
			}
			if($ssCat!="%%"){
				$condition = $condition." and idsscat like '".$ssCat."'";
			}
			if($feuil!="%%"){
				$condition = $condition." and idfeuil like '".$feuil."'";
			}

			$sql = "select idpro,codepro,nompro,prix,description,dosage,disponibilite,nomtype,nomimage from produitclass where 1 ".$condition." limit ".$limit." offset ".$offset;
			
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			//echo count($retour);
			$this->db->close();
			return $retour;
		
		}	

		public function getCategorie(){
			$sql = "select idcat,nomcat from categorie";
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;

		}

		public function getSousCategorie($cat){

			$sql = "select sc.idscat,sc.nomsouscat from souscategorie sc join categoriesouscat csc on sc.idscat = csc.idscat where csc.idcat=".$cat;
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		public function getsSousCat($sCat){

			$sql = "select ssc.idsscat,ssc.nomsscat from soussouscategorie ssc join souscategoriesous2cat scsc on ssc.idsscat = scsc.idsscat where scsc.idscat=".$sCat;
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}


		public function getFeuille($ssCat){

				$sql = "select f.idfeuil,f.nomfeuil from feuille f join sous2categoriefeuille sscfeuille on f.idfeuil = sscfeuille.idfeuil where sscfeuille.idsscat=".$ssCat;
			//echo($sql);
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}
		
	}
