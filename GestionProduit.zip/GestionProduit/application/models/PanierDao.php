<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PanierDAO extends CI_Model {

		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function creerPanier($idkil){
			$sql = "insert into panier (`IDPANIER`, `LADATE`, `IDCLIENT`, `ETAT`) VALUES (NULL, now(), '".$idkil."', 0)";
			echo $sql;
			$this->db->query($sql);
			$this->db->close();
		}


		public function registerPanier($idpanier,$nom,$etat,$idmodel){
			$sql = "UPDATE  `basefacturation`.`panier` SET  `LADATE` =  now(),
						`ETAT` =  '".$etat."',
						`IDMODEL` =  '".$idmodel."',
						`NOM` =  '".$nom."' WHERE  `panier`.`IDPANIER` ='".$idpanier."'";
			$this->db->query($sql);
			$this->db->close();
		}


		public function setEtatPanier($idpanier,$etat){
			$sql = "UPDATE  `basefacturation`.`panier` SET  `ETAT` =  '".$etat."' WHERE  `panier`.`IDPANIER` =".$idpanier;
			$this->db->query($sql);
			$this->db->close();
		}

		public function getIdPanierNoRegister($idkil){
			$sql = "select idpanier from panier where idclient like '".$idkil."' and etat = 0";
			$result = $this->db->query($sql);
			$retour = $result->row_array();
			$this->db->close();
			if($retour['idpanier']==null)
				throw new Exception("return null");
			else	
				return $retour['idpanier'];
		}


		public function getPanierNoRegister($idkil){
			$sql = "select idpanier,ladate from panier where idclient like '".$idkil."' and etat = 0";
			$result = $this->db->query($sql);
			$retour = $result->row_array();
			$this->db->close();
			
				return $retour;
		}

		public function creerDetailPanier($idpro,$idpanier,$quantite){

			$sql = "insert into detailpanier (`IDDETAIL`,`IDPANIER`, `IDPRODUIT`, `QUANTITE`) VALUES (NULL, '".$idpanier."', '".$idpro."', '".$quantite."')";
			$this->db->query($sql);
			$this->db->close();
		}

		public function isProduitInPanier($idpro,$idpanier){
			$sql = "select iddetail from detailpanier where IDPRODUIT like '".$idpro."' and idpanier like '".$idpanier."'";
			$result = $this->db->query($sql);
			$retour = $result->row_array();
			$this->db->close();
			
			if($retour==null)
				throw new Exception("return null");
				
			else return $retour['iddetail'];
		}

		public function incrementQuantitePro($iddetail,$nbre){

			$sql = "UPDATE  `basefacturation`.`detailpanier` SET  `QUANTITE` =  '".$nbre."' WHERE  `detailpanier`.`IDDETAIL` =".$iddetail;
			$this->db->query($sql);
			$this->db->close();

		}

		public function majDatePanier($idpanier){
			$sql = "UPDATE  `basefacturation`.`panier` SET  `LADATE` = now() WHERE  `panier`.`IDPANIER` =".$idpanier;
			echo $sql;
			$this->db->query($sql);
			$this->db->close();
		}

		public function getNbresProduitInPanier($idpanier){
			$sql = "select sum(quantite)size from detailpanier where idpanier like '".$idpanier."' group by IDPANIER";
			$result = $this->db->query($sql);
			$retour = $result->row_array();
			$this->db->close();
			if( $retour['size']==0) throw new Exception("resultat vide");
			return $retour['size'];
		}

		public function getModele($idkil){
			$sql = "SELECT DISTINCT IDMODEL,NOM FROM modelepanier
					WHERE IDMODEL IN (
					  SELECT IDMODEL
					  FROM panier where etat = 1 and idclient like'".$idkil."' group by IDMODEL
					)";
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		public function getAllModel(){
			$sql = "select idmodel,nom from modelepanier";
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		public function getPanierByModel($idmodel,$idkil){
			$sql = "select idpanier,ladate,idclient,nom from panier where IDMODEL like '".$idmodel."' and etat=1 and IDCLIENT like '".$idkil."'";
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		public function getDetailByPanier($idpanier){
			$sql = "select d.iddetail,d.idpanier,d.quantite,ip.idpro,ip.nompro,ip.prix,ip.codepro,ip.description,ip.disponibilite,ip.dosage,ip.nomimage,ip.nomtype from detailpanier d join imageproduit ip on d.idproduit = ip.idpro where d.IDPANIER like '".$idpanier."'";
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		public function dropDetail($iddetail){
			$sql = "delete from  `basefacturation`.`detailpanier` WHERE  `detailpanier`.`IDDETAIL` =".$iddetail;
			$this->db->query($sql);
			$this->db->close();
		}

		public function viderPanier($idpanier){
			$sql = "delete from  `basefacturation`.`detailpanier` WHERE  `detailpanier`.`IDPANIER` =".$idpanier;
			$this->db->query($sql);
			$this->db->close();
		}

		public function getDetailPanierByIdPanier($idpanier){
			$sql = "select d.iddetail,d.quantite,d.idproduit from detailpanier d where d.IDPANIER like '".$idpanier."'";
			$result = $this->db->query($sql);
			$retour = $result->result_array();
			$this->db->close();
			return $retour;
		}

		
	}