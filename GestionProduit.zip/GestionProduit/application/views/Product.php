<?php //include_once("fonction.php");?>
<?/*php $tab2=getCategorieParCsc($_GET['sc']);
	$tab3 = getSousCategorieParCsc($_GET['sc']) ;
	$tab4 = getSousCategorie($tab2[0]['codecategorie']);*/?>

	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Home</a><span>|</span></li>
				<li><?php //echo $tab3[0]['nomsouscategorie'];?></li>
			</ul>
		</div>
</div>
<div class="banner">
		<?php// include("menuVerticaleDroite.php");?>	
		
		<div class="w3l_banner_nav_right">
			<div class="w3l_banner_nav_right_banner3">
				<h3>Best Deals For New Products<span class="blink_me"></span></h3>
			</div>
			<div class="clearfix"></div>
			<div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
				<h3><? //php echo $tab2[0]['nomcategorie']; ?></h3>
				<?php
					//for ($i=0;$i<count($tab4);$i++){ ?>
				<div class="w3ls_w3l_banner_nav_right_grid1">
					
					<h6><?php //echo $tab4[$i]['nomsouscategorie']?></h6>
					<?php /*$tab5 = getProduitParSc($tab4[$i]['codesouscategorie'],"codesouscategorie");
					for ($/*ii=0;$ii<count($tab5);$ii++){ 
						$image = getImg($tab5[$ii]['codeproduit']);
						$produit = getProduit($tab5[$ii]['codeproduit']);
						$remise = getPrix($tab5[$ii]['codeproduit']);*/?>
					<div class="col-md-3 w3ls_w3l_banner_left">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid_pos">
								<img src="images/offer.png" alt=" " class="img-responsive" />
							</div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<a href="index.php?page=single&codeproduit=<?php //echo $produit[0]['codeproduit'];?>"><img src="images/<?php //echo $image[0]['nomimage']; ?>" alt=" " class="img-responsive" /></a>
											<p><?php //echo $produit[0]['nomproduit']."  ".$produit[0]['quantite'] ; ?></p>
											<h4>$<?php //echo $remise[0]['prix'];?><span>$<?php //echo $produit[0]['prix'].".00"; ?></span></h4>
										</div>
										<div class="snipcart-details">
											<form action="#" method="post">
												<fieldset>
													<input type="hidden" name="cmd" value="_cart" />
													<input type="hidden" name="add" value="1" />
													<input type="hidden" name="business" value=" " />
													<input type="hidden" name="item_name" value="<?php// echo $produit[0]['nomproduit']; ?>" />
													<input type="hidden" name="amount" value="<?php //echo $produit[0]['prix'].".00"; ?>" />
													<input type="hidden" name="discount_amount" value="1.00" />
													<input type="hidden" name="currency_code" value="USD" />
													<input type="hidden" name="return" value=" " />
													<input type="hidden" name="cancel_return" value=" " />
													<input type="submit" name="submit" value="Add to cart" class="button" />
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
					
					<?php //} ?>
					<div class="clearfix"> </div>
				</div>
						<?php //} ?>
	</div>
</div>
<div class="clearfix"></div>
</div>