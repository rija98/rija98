<div id="menu1">
            <ul id="accordeon">

                <?php foreach ($cat as $detailcat){?>
                        <li>
                            <a href="<?php echo site_url('Controlleur/getPro/100/0?cat='.$detailcat['idcat']);?>"><h3 ><?php echo $detailcat['nomcat'];?></h3></a>  

                                <ul>

                                  <?php foreach ($detailcat['scat'] as $scat){?>
                                        
                                        <li>
                                            <a href="<?php echo site_url('Controlleur/getPro/100/0?scat='.$scat['idscat']);?>"><h4 ><?php  echo $scat['nomsouscat'];?></h4></a>


                                                <ul>

                                                 <?php foreach ($scat['sscat'] as $sscat){?>


                                                        <li>
                                                           <a href="<?php echo site_url('Controlleur/getPro/100/0?sscat='.$sscat['idsscat']);?>"><h5 ><?php echo $sscat['nomsscat'];?></h5></a>

                                                                <ul>

                                                                 <?php foreach ($sscat['feuil'] as $feuil){?>

                                                                        <li>
                                                                             <a href="<?php echo site_url('Controlleur/getPro/100/0?feuil='.$feuil['idfeuil']);?>"><small><?php echo $feuil['nomfeuil'];?></small></a>

                                                                            <br>

                                                                        </li>
                                                              <?php }?>
                                                                </ul>
                                                        </li>
                                                 <?php }?> 
                                                </ul>
                                        </li>
                              <?php }?>

                               </ul>

                        </li>
                    <?php }?>

                </ul>
            </div>








  