 <h1><?php echo $nom ?></h1>
 <h2><?php echo $prenom ?></h2>