
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8" />
  <link rel="icon" type="image/png" href="<?php echo base_url();?>assets/img/favicon.ico">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title>Site</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />


    <link href="<?php echo base_url();?>assets/botstrapTab/css/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>assets/botstrapTab/css/fresh-bootstrap-table.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">

     <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
        
   

</head>
<body onload="getTotalPanier();">

  <div class="container">

      <?php include('head.php');?>
      <?php include($page.'.php');?>
  </div>

</body>

  <!--respecter les numeros des script pour bien fonctionnner le site-->
  
 <!--1_script bootstrap/jquery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

  <!--2_script table bootstrap(acceuil.php)-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/botstrapTab/js/jquery-1.11.2.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/botstrapTab/js/bootstrap.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>assets/botstrapTab/js/bootstrap-table.js"></script>


  <!--3_script modal connection(head.php)-->
  <script>
      $('#exampleModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var recipient = button.data('connect') // Extract info from data-* attributes
      // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
      // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
      var modal = $(this)
      modal.find('.modal-title').text('Se connecter ')
      modal.find('.modal-body input').val(recipient)
  })
  </script>



<!--4_recupere valeur dans modal-->
  <script type="text/javascript">
    function parameteModalAjoutPanier(id, name, dispo){
            $(".modal-body #hiddenValue").val(id);
            $(".modal-body #nompro").text(name);
            $(".modal-body #quantite").attr("max",dispo);
    }

  </script>


  <!--5_script table bootstrap -->
    <script type="text/javascript">
        var $table = $('#fresh-table'),
            $alertBtn = $('#alertBtn'),
            full_screen = false;
            
        $().ready(function(){
            $table.bootstrapTable({
                toolbar: ".toolbar",
    
                //showRefresh: true,
                search: true,
                showToggle: true,
                //showColumns: true,
                pagination: true,
                striped: true,
                pageSize: 5,
                pageList: [5,11,20],
                
                formatShowingRows: function(pageFrom, pageTo, totalRows){
                    //do nothing here, we don't want to show the text "showing x of y from..." 
                },
                formatRecordsPerPage: function(pageNumber){
                    return pageNumber + " rows visible";
                },
                icons: {
                    refresh: 'fa fa-refresh',
                    toggle: 'fa fa-th-list',
                    columns: 'fa fa-columns',
                    detailOpen: 'fa fa-plus-circle',
                    detailClose: 'fa fa-minus-circle'
                }
            });
            
                        
            
            $(window).resize(function () {
                $table.bootstrapTable('resetView');
            });
    

             window.operateEvents = {
                
                'click .edit': function (e, value, row, index) {
                   // alert('You click edit icon, row: ' + JSON.stringify(value));
                   
                    //console.log(value, row, index);    
                },
                'click .remove': function (e, value, row, index) {
                    $table.bootstrapTable('remove', {
                        field: 'image',
                        values: [row.image]
                    });
                    var index1 = row.name.indexOf('>');
                   var index2 = row.name.lastIndexOf('<');
                   var iddetail = row.name.slice(index1+1,index2);
                   console.log(iddetail);
                   
                    var url = "<?php echo site_url('Controlleur/dropDetailJs');?>";
                      url +="/"+iddetail;
                      alert(url);
                       $(this).load(url, function(responseTxt, statusTxt, xhr){
                              if(statusTxt == "success")
                                  alert(" External content loaded successfully!");
                              if(statusTxt == "error")
                                  alert("Error: " + xhr.status + ": " + xhr.statusText);
                      });
                      //maj size of panier (head.php)
                      getTotalPanier();
                }
            };
            /*
            window.operateEvents = {
                'click .detail': function (e, value, row, index) {
                    alert('You click like icon, row: ' + JSON.stringify(row));
                    console.log(value, row, index);
                },
                'click .panier': function (e, value, row, index) {
                    alert('You click edit icon, row: ' + JSON.stringify(row));
                    console.log(value, row, index);    
                }
            };*/
            
            $alertBtn.click(function () {
                alert("You pressed on Alert");
            });
            
        });
            

          function operateFormatter(value, row, index) {
            return [
                
                '<a rel="tooltip" title="Voir plus" class="table-action edit" href="javascript:void(0)" title="Voir plus">',
                    '<i class="fa fa-eye-slash"></i>',
                '</a>',
                '<a rel="tooltip" title="Remove" class="table-action remove" href="javascript:void(0)" title="Remove">',
                    '<i class="fa fa-remove"></i>',
                '</a>'
            ].join('');
        }
          
    /*
         function operateFormatter(value, row, index) {
            return [
                '<a rel="tooltip" title="voir plus" class="table-action detail" href="javascript:void(0)" title="detail">',
                    '<i class="fa fa-eye-slash"></i>',
                '</a>',
                '<a rel="tooltip" title="ajouter au panier" class="table-action panier" href="javascript:void(0)" title="panier">',
                    '<i class="fa fa-shopping-cart"></i>',
                '</a>'
            ].join('');
        }
    
            */
    </script>



  <!-- maj : sizeOfPanier(head.php)      totalPanier,TotalPartial,majBaseAftersetQuantite(panier.php)-->  
<script type="text/javascript">
    
    //var l = document.querySelector('#somme');
    
    //l.innerHTML=somme;
    function round(value, decimals) {
          return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
        }


    function getTotalPanier(){

        var tabs = document.querySelectorAll('.TotalPartial');
        
        if(tabs.length>0){
            var sum = 0;
              for (var i = 0; i < tabs.length; i++) {
                 sum+= parseFloat(tabs[i].textContent); 
              }
              sum = round(sum,2);
             document.querySelector('#somme').textContent=sum;
             
             var size = 0;
             var selet = document.querySelectorAll('#sel select');
              for (var ii = 0; ii < selet.length; ii++) {
                  //alert(selet[ii].value);
                 size+= parseInt(selet[ii].value); 
              }
              if(size==0){
                  sizePanierIsNull();
              }
              if(!size){
                size=0;
                //console.log("mety"+size+"////");
              }
        document.querySelector('#sizePanier').textContent="("+size+")";
        }

    }

    //maj div de table panierActuelle dans (panier.php)
    function sizePanierIsNull(){
        var divtable = document.querySelector('.toolbarDiv');

        divtable.innerHTML ="<span>VOTRE PANIER est VIDE ajouter des produits ou utiliser vos modeles de panier</span>" ;
    }

    //majBd apres change quantite of details panier actuelle
    function selectHasClicked(value,iddetail,prix,idpanier){
        var total = value*prix;
        //alert(idpanier);
        var totalElt = document.querySelector('#quant'+iddetail);
        //alert('= '+total.ElttextContent);
        total = round(total,2);
        totalElt.textContent=total;
        getTotalPanier();
        
        var url = "<?php echo site_url('Controlleur/incrementDetailJs');?>";
        url +="/"+iddetail+"/"+idpanier+"?quantite="+value;
        alert(url);
         $(this).load(url, function(responseTxt, statusTxt, xhr){
                if(statusTxt == "success")
                    alert(" External content loaded successfully!");
                if(statusTxt == "error")
                    alert("Error: " + xhr.status + ": " + xhr.statusText);
        });
    }
</script>
</html>