
<div class="wrapper">

        <div class="row">

                <div class="col-md-2">

                       <div id="menu1">
                            <ul id="accordeon">
                                    <li>
                                        <a href="<?php //echo site_url('Controlleur/getInitialPanierView');?>">EN COURS REGLENENT</a>
                                    </li>
                                
                                    <li>
                                        <a href="<?php //echo site_url('Controlleur/getPanierView/'. $model['IDMODEL']."/".$model['NOM']);?>">HISTORIQUES</a>
                                    </li>
                            </ul>
                        </div>

                </div>

                <div class="col-md-10">

						<div class="row">
							<h3>FACTURE <span>EN COURS REGLEMENT</span></h3>

							<?php   if(count($facturesImpayes)>0) {  

                                        include('collapseFacture.php');
                                
                                    }else{ ?>
                                        <p>Tout est regle</p>
                                    <?php }?>
                            

						</div>
                    
						
            </div>

            </div>

</div>
           



<!--modal code-->
<div class="modal fade" id="PayerFacture" tabindex="-1" role="dialog" aria-labelledby="my_modalLabel">
    <div class="modal-dialog" role="dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Enregister un panier</h4>
            </div>

            <form action="<?php echo site_url('Controlleur/registerPanier/'.$panierCourante['idpanier'].'');?>" method="get">
                    <div class="modal-body">
                        <label>mode payement:</label>
                        <select name="selectModePayement">
                            <?php //foreach($allModels as $allModel){?>
                                <option value="<?php echo //$allModel['idmodel'];?>"><?php //echo $allModel['nom'];?></option>
                            <?php //}?>
                        </select>
                        <label>Montant:</label>
                            <input type="number" name="montantApayer">

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-success" value="yes">Ajouter</button>
                    </div>    
            </form>
            
        </div>
    </div>
</div>