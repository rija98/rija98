
<div class="wrapper">

        <div class="row">""

                <div class="col-md-2">

                       <div id="menu1">
							<h4>Listes Modeles Panier</h4>
                            <ul id="accordeon">
                                    <li>
                                        <a href="<?php echo site_url('Controlleur/getInitialPanierView');?>">TOUS</a>
                                    </li>
                                <?php foreach($models as $model){?>
                                    <li>
                                        <a href="<?php echo site_url('Controlleur/getPanierView/'. $model['IDMODEL']."/".$model['NOM']);?>"><?php echo $model['NOM']?></a>
                                    </li>
                                <?php }?>
                            </ul>
                        </div>

                </div>

                <div class="col-md-10">

						<div class="row">
							<h3>LISTE PANIER MODELE <?php echo $nomModelSelectionne;?></h3>

							<?php   if(count($listePaniers)>0) {  

                                        include('collapsePanier.php');
                                
                                    }else{ ?>
                                        <p>Aucun panier enregistré ,</p>
                                        <p>En enregistrant vos paniers ,</p>
                                        <p>Vous pourrez les voir ICI</p>
                                    <?php }?>
                            

						</div>
                    
						<div class="row">
                            <div class="fresh-table ">
                            <!--    Available colors for the full background: full-color-blue, full-color-azure, full-color-green, full-color-red, full-color-orange                  
                                    Available colors only for the toolbar: toolbar-color-blue, toolbar-color-azure, toolbar-color-green, toolbar-color-red, toolbar-color-orange
                            -->
                                <?php if ($panierSize==0){?>
                                        <span>VOTRE PANIER est VIDE</span>
                                        <span>ajouter des produits ou utiliser vos modeles de panier</span>
                                <?php } 
                                else{?>
                                <div  class="toolbar toolbarDiv">
                                    
                                    <button id="alertBtn" class="btn btn-default">Alert</button>
									<span>PANIER
                                        <sub>modifié le <?php echo $panierCourante['ladate'];?>
                                        </sub>
                                    </span>
									<button onclick="window.location.href='<?php echo site_url('Controlleur/viderPanier/'.$panierCourante['idpanier']);?>'" type="button" class="btn btn-danger btn-xs">
                                        vider
                                    </button>
                                    <button data-target="#registerPanier" data-toggle="modal" type="button" title="enregistrer ce panier pour en creer un modele" class="btn btn-info btn-xs">
                                        enregistrer
                                    </button>
                                    <button  type="button" class="btn btn-success btn-xs">
                                        facturer
                                    </button>
									<span style="margin-left: 70px;">TOTAL : <span id="somme" style="color: red;"></span> EUR</span>
                                </div>
                                 
                                <table  id="fresh-table" class="table">
                                   
                                    <thead>
                                       
                                        <th data-field="image">Image</th>
                                        <th data-field="name" data-sortable="true">Libellé</th>
                                        <th data-field="prix" data-sortable="true">P.U</th>
                                        <th data-field="devise">devise</th>
                                        <th data-field="disponibility" data-sortable="true">quantité</th>
                                        <th data-field="total">total</th>
                                        <th data-field="actions" data-formatter="operateFormatter" data-events="operateEvents">Actions</th>
                                    </thead>
                                    <tbody >

                                       
                                        <?php foreach($panierCourante['details'] as $val) {?>
                                            <tr>
                                                
                                                <td>
                                                    <img src="<?php echo base_url();?>assets/img/<?php echo $val['nomimage'];?>.png">
                                                </td>
                                                <td><?php echo $val['nompro'];?><span style="display: none"><?php echo $val['iddetail'];?></td></span>
                                                <td><?php echo $val['prix'];?></td>
                                                <td>EUR</td>
                                                <td id="sel">

                                                        <select onchange="selectHasClicked(this.value,<?php echo $val['iddetail'];?>,<?php echo $val['prix'];?>,<?php echo $panierCourante['idpanier'];?>);" name="quantity" >
                                
                                                                <?php $max =  $val['disponibilite'];
                                                                for($i=1;$i<=$max;$i++){

                                                                    if($i == $val['quantite']){?>
                                                                        <option value="<?php echo $i;?>" selected="">
                                                                            <?php echo $i;?>
                                                                        </option>
                                                                    <?php } else{?>
                                                                        <option value="<?php echo $i;?>" >
                                                                        <?php echo $i;?>
                                                                        </option>

                                                                    <?php }
                                                                }?>
                                                                <option value="" >
                                                                    +quantit
                                                                    é
                                                                </option>
                                                        </select>
                                                </td>
                                                <td>
                                                    <p class="TotalPartial" id="quant<?php echo $val['iddetail'];?>">
                                                        <?php 
                                                        echo $val['quantite']*$val['prix'];
                                                        ?>
                                                   </p>
                                                   
                                                </td>
                                                <td>
                                                    
                                                </td>
                                            </tr>
                                        <?php }?>


                           
                            
                                    </tbody>
                                </table>
                                    <?php }?>

                            </div>
                        </div>   
                    </div>

            </div>

        </div>
           



<!--modal code-->
<div class="modal fade" id="registerPanier" tabindex="-1" role="dialog" aria-labelledby="my_modalLabel">
    <div class="modal-dialog" role="dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Enregister un panier</h4>
            </div>

            <form action="<?php echo site_url('Controlleur/registerPanier/'.$panierCourante['idpanier'].'');?>" method="get">
                    <div class="modal-body">
                        Condition:
                        <p>.Vous ne pouvez plus ajouter ni enlever des details</p>
                        <p>.Ce panier sera visible dans votre Model de panier</p>
                        <label>Enter un nom pour votre panier:</label>
                        <input type="text" name="name" >
                        <label>Selectionner un model pour votre panier:</label>
                        <select name="selectModelPanier">
                            <?php foreach($allModels as $allModel){?>
                                <option value="<?php echo $allModel['idmodel'];?>"><?php echo $allModel['nom'];?></option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-success" value="yes">Ajouter</button>
                    </div>    
            </form>
            
        </div>
    </div>
</div>