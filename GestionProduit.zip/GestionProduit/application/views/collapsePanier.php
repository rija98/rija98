<div class="accordion" id="accordionExample">
	<?php foreach($listePaniers as $panier){ ?>
			  <div class="card">
				    <div class="card-header" id="headingOne">
				      <h5 class="mb-0">
				       
				        <a  class="btn btn-link" type="button" data-toggle="collapse"  data-target="#<?php echo $panier['idpanier'];?>" aria-expanded="true" aria-controls="collapseOne">
				          <?php echo $panier['nom'];?>
				        </a>
				         édité le <?php echo $panier['ladate'];?>

				      </h5>
				    </div>


			    <div id="<?php echo $panier['idpanier'];?>" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
			      <div class="card-body">
				        <table class="table table-condensed">
						    <thead>
						      <tr>
						        <th>libellé</th>
						        <th>p.u</th>
						        <th>quantité</th>
						        <th></th>
						        <th>total</th>
						      </tr>
						    </thead>
						    <tbody>
						    	<?php $total=0; foreach ($panier['details'] as $detail ) { ?>
						    		<form action="<?php echo site_url('Controlleur/incrementDetail/'.$detail['iddetail'].'/'.$panier['idpanier']);?>" method="get">
						    				<tr>
										        <td><?php echo $detail['nompro'];?></td>
										        <td><?php echo $detail['prix'];?> EUR</td>
										        <td>
										        	<input type="number" name="quantite" value="<?php echo $detail['quantite'];?>" min="0" max="<?php echo $detail['disponibilite'];?>"/>
										        </td>
										        <td>
										        	<button type="submit" class="btn btn-primary btn-xs">update</button>
										        </td>
										        <td><?php $total += $detail['quantite']*$detail['prix']; echo $detail['quantite']*$detail['prix']; ?> EUR</td>
										     </tr>
						    		</form>
						    		
						    	<?php } ?>

						      		<tr>
						      			<td></td>
						      			<td></td>
						      			<td></td>
						      			<td>TOTAL DU PANIER</td>
						      			<td><?php echo $total;?> EUR</td>
						      		</tr>
						    </tbody>
					  	</table>
					  	<a type="button" href="<?php echo site_url('Controlleur/dropPanier/'.$panier['idpanier']);?>"class="btn btn-danger btn-xs">supprimer</a>
					  	<a type="button" href="<?php echo site_url('Controlleur/usePanier/'.$panier['idpanier'].'/'.$panierCourante['idpanier']) ;?>" title="ajouter ces produits dans le panier courant" class="btn btn-info btn-xs">utiliser</a>
			            <a type="button" class="btn btn-success btn-xs">facturer</a>
			      </div>
			    </div>
  </div>
  <?php }?>
</div>
 