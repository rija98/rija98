
<div class="wrapper">
    <div class="container">
        <div class="row">
            <h5><label>Date : </label>12/12/17</h5>
            <h5><label>Client : </label>Nas</h5>
            <h5><label>Num Fact : </label>F004</h5>
            <h4 class="ci">Insertion Produit</h4>
        </div>
        <div class="row">
            <form class="col-md-6 col-md-offset-3 centre">
                <div class="form-group">
                   <label for="pro">Select Produit (select one):</label>
                          <select class="form-control" id="pro">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                </div>
                <div class="form-group">
                    <label for="pu">P.U:</label>
                    <input type="text" class="form-control" id="pu">
                </div>
                <div class="form-group col-md-offset-8">
                    <label for="qt">Quantite :</label>
                    <input type="number" name="quantity" min="1" max="5">
                </div>
                <div class="form-group"> 
                    <label for="total">Total :</label>
                    <input type="text" class="form-control" name="total">
                </div>
                
                    <button style="text-align: center;" type="submit" class="btn btn-default">ok
                    </button>
                
                    
                
               
            </form>
        </div>


    </div>   
 
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                                
                <div class="fresh-table ">
                <!--    Available colors for the full background: full-color-blue, full-color-azure, full-color-green, full-color-red, full-color-orange                  
                        Available colors only for the toolbar: toolbar-color-blue, toolbar-color-azure, toolbar-color-green, toolbar-color-red, toolbar-color-orange
                -->
                
                    <div class="toolbar">
                        <button id="alertBtn" class="btn btn-default">Alert</button>
                    </div>
                    
                    <table id="fresh-table" class="table">
                        <thead>
                            <th data-field="codePro">CodeProduit</th>
                        	<th data-field="name" data-sortable="true">Nom</th>
                        	<th data-field="prix" data-sortable="true">Prix</th>
                        	<th data-field="disponibility" data-sortable="true">Stock</th>
                            <th>Quantite</th>
                        	<th>Actions</th>
                        </thead>
                        <tbody>
                            <?php foreach($data as $val) {?>
                            <tr>
                            	<td><?php echo $val['CODEPRO'];?></td>
                            	<td><?php echo $val['NOMPRO'];?></td>
                            	<td><?php echo $val['PRIX'];?> EURO</td>
                                <td><?php echo $val['DISPONIBILITE'];?></td>
                                <td><input  ></td>>
                            	<td><a href="<?php echo site_url('Welcome/ajoutPanier/');?>">+ PANIER</a></td>
                            	
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
                
                
            </div>
        </div>
    </div>
</div>
