<div class="accordion" id="accordionExample">
	<?php// foreach($factures as $fact){ ?>
			  <div class="card">
				    <div class="card-header" id="headingOne">
				      <h5 class="mb-0">
				       
				        <a  class="btn btn-link" type="button" data-toggle="collapse"  data-target="#R<?php echo// $panier['idpanier'];?>" aria-expanded="true" aria-controls="collapseOne">
				          <?php// echo $panier['nom'];?>#numFacture
				        </a>

				      </h5>
				    </div>


			    <div id="R<?php echo// $panier['idpanier'];?>" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
			      <div class="card-body">
			      	<h4 style="text-align: center;">Details</h4>
				        <table class="table table-condensed">
						    <thead>
						      <tr>
						        <th>CodePro</th>
						        <th>libelle</th>
						        <th>p.u</th>
						        <th>quantité</th>
						        <th>remise</th>
						        <th>total</th>
						      </tr>
						    </thead>
						    <tbody>
						    	<?php //foreach ($panier['details'] as $detail ) { ?>
						      		<tr>
						      			<td></td>
						      			<td></td>
						      			<td></td>
						      			<td>TOTAL DU PANIER</td>
						      			<td><?php //echo $total;?> EUR TTC</td>
						      		</tr>
						      		<tr>
						      			<td></td>
						      			<td></td>
						      			<td></td>
						      			<td>REMISE FACTURE</td>
						      			<td><?php //echo $total;?> 20 %</td>
						      		</tr>
						      		<tr>
						      			<td></td>
						      			<td></td>
						      			<td></td>
						      			<td>REMISE CLient</td>
						      			<td><?php //echo $total;?> 1%</td>
						      		</tr>
						      		<tr>
						      			<td></td>
						      			<td></td>
						      			<td></td>
						      			<td>TOTAL TOTAL A PAYER</td>
						      			<td><?php //echo $total;?> EUR TTC</td>
						      		</tr>
						      		<?php //};?>
						    </tbody>
					  	</table>

					  	<h4 style="text-align: center;">Reglement (date Debut:j/m/a  // date fin: j/m/a)</h4>
					  	<table class="table table-condensed">
						    <thead>
						      <tr>
						        <th>tranche</th>
						        <th>Mode</th>
						        <th>montant</th>
						      </tr>
						    </thead>
						    <tbody>
						      		<tr>
						      			<td></td>
						      			<td>Payer</td>
						      			<td>EUR</td>
						      		</tr>

						      		<tr>
						      			<td></td>
						      			<td>Reste</td>
						      			<td>EUR <button data-target="#PayerFacture" data-toggle="modal">Regler</button></td>
						      		</tr>
						    </tbody>
					  	</table>
			      </div>
			    </div>
  </div>
  <?php// }?>
</div>
 