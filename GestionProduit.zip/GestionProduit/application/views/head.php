
  <?php 
  $username = "";
  $action = "connecter";
  if( $this->session->userdata('pseudo') != null){
     $user = $this->session->userdata('pseudo');
      $username = $user['nom'];
      $action = "deconnecter";
  }?>

  <div style="background-color: beige;" class="row">
  
    <div class="col-md-10">

        <div class="row"> 

              <div class="col-md-3">
                <a  href="#">Menu</a>
              </div>
              
              <div class="col-md-2">
                 <a class="nav-link" href="<?php echo site_url('Controlleur');?>">Liste Produit</a>
              </div>

              <div class="col-md-2">
                   <?php if($action == "connecter"){?>  

                        <a  href="" onclick="alert('un authentification requise');">
                                                                <i class="fa fa-shopping-cart"></i>
                                                        </a>

                   <?php } else{?>

                        <a class="nav-link" href="<?php echo site_url('Controlleur/getInitialPanierView');?>"><i class="fa fa-shopping-cart"></i><span id="sizePanier">(<?php echo $panierSize;?>)</span></a>

                   <?php }?>
                 
              </div>
              <div class="col-md-2">
                  <?php if($action == "connecter"){?>  

                        <a  href="" onclick="alert('un authentification requise');">
                                                               facture
                                                        </a>

                   <?php } else{?>

                        <a class="nav-link" href="<?php echo site_url('FactureControlleur/facturerPanier/1');?>">
                          facture
                        </a>

                   <?php }?>
              </div>
                  
              <div class="col-md-3"> 
                  <?php if($action == "connecter"){?>  
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="">Connecter</button>
                  <?php }
                  else {?>
                    <a type="button" class="btn btn-primary" href="<?php echo site_url('Controlleur/deconnect');?>" data-whatever="">Deconnecter</a>
                  <?php }?>
              </div>

        </div>
    </div>
      <?php if($action!="connecter"){?>
        <div class="col-md-2">
          <h7><?php echo $username;?></h7>
        </div>
      <?php }?>

</div>



<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Se connecter</h5>
      </div>
      <form action="<?php echo site_url('Controlleur/login')?>" method="post">
      <div class="modal-body">
        
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Username:</label>
            <input type="text" class="form-control" name="login" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="mdp-text" class="col-form-label">password:</label> 
            <input type="password" class="form-control" name ="pass" id="mdp-text">
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">cancel</button>
        <button type="submit" class="btn btn-primary" value="login">login</button>
      </div>
      </form>
    </div>
  </div>
</div>