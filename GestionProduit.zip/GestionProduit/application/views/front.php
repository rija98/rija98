 <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>assets/css/fresh-bootstrap-table.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>assets/css/style1.css" rel="stylesheet" />
     
     <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
     


     
 
        <div class="row">
            <div class="col-md-8 center">
                                
                <div class="fresh-table ">
                <!--    Available colors for the full background: full-color-blue, full-color-azure, full-color-green, full-color-red, full-color-orange                  
                        Available colors only for the toolbar: toolbar-color-blue, toolbar-color-azure, toolbar-color-green, toolbar-color-red, toolbar-color-orange
                -->
                
                    <div class="toolbar">
                        <button id="alertBtn" class="btn btn-default">Alert</button>
                    </div>
                    
                    <table id="fresh-table" class="table">
                        <thead>
                            <th data-field="codePro">CodeProduit</th>
                        	<th data-field="name" data-sortable="true">Nom</th>
                        	<th data-field="prix" data-sortable="true">Prix</th>
                        	<th data-field="disponibility" data-sortable="true">Stock</th>
                            <th>Quantite</th>
                        	<th>Actions</th>
                        </thead>
                        <tbody>
                            <?php foreach($data as $val) {?>
                            <tr>
                            	<td><?php echo $val['CODEPRO'];?></td>
                            	<td><?php echo $val['NOMPRO'];?></td>
                            	<td><?php echo $val['PRIX'];?> EURO</td>
                                <td><?php echo $val['DISPONIBILITE'];?></td>
                                <td><input  ></td>>
                            	<td><a href="<?php echo site_url('Welcome/ajoutPanier/');?>">+ PANIER</a></td>
                            	
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
                
                
            </div>
        </div>
