<h4 class="ci">Login</h4>

<form class="col-md-6 col-md-offset-3" method="post" action="<?php echo site_url('Welcome/seConnecter');?>">
              <!-- <form class="col-md-6 col-md-offset-3" type="post" action="<?php //echo site_url('Welcome/validerLogin');?>">-->
               
 
               <!-- <div class="form-group">
                    <label for="dat">Date :</label>
                    <input type="Date" class="form-control" id="dat">
                </div>
                
                <div class="form-group"> 
                    <label for="cli">Code Client :</label>
                    <input type="text" class="form-control" name="cli">
                </div>
                
                <div class="form-group"> 
                    <label for="nfact">Num Fact :</label>
                    <input type="text" class="form-control" name="nfact">
                </div>

                    <button style="text-align: center;" type="submit" class="btn btn-default">ok
                    </button>
                -->

                <div class="form-group"> 
                    <label for="login">LOGIN :</label>
                    <input type="text" class="form-control" name="login">
                </div>
                
                <div class="form-group"> 
                    <label for="mdp">MDP :</label>
                    <input type="password" class="form-control" name="mdp">
                </div>

                    <button style="text-align: center;" type="submit" class="btn btn-default">se connecter
                    </button>
              
            </form>

