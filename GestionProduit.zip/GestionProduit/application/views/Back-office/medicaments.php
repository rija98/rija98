<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Accueil</title>
    
    <body>
        
      <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Inserer Commande</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                                    
                                            <label>date : </label>
                                            <input type="text" class="form-control" name="date">
                                            <label>Client : </label>
                                            <input type="text" class="form-control" name="client"> 
                                            <label>num facture : </label>
                                            <input type="text" class="form-control" name="facture">

                                            <a href="<?php echo base_url();?>index.php/Welcome/getpage2" value="ajouter">Ajouter</a>
                                       
                                
                            </div>
                            <!-- /.panel-body -->
                     
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

        <?php $this->load->view('Back-office/footer'); ?>

    </body>

</html>
