<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Accueil</title>
        <?php $this->load->view('Back-office/head'); ?>
        <?php $this->load->view('Back-office/styletable'); ?>

        
        
    
    </head>

    <body>
        <?php $this->load->view('Back-office/header'); ?>
        <?php $this->load->view('Back-office/menu');?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Commande</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                 <div class="col-sm-4">
                    <button type="button" class="btn btn-info add-new">Export Excel</button>
                </div>
                <div class="col-sm-4">
                    <button type="button" class="btn btn-info add-new"></i>Export pdf</button>
                </div>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <form method = "post" action="<?php echo base_url();?>index.php/Back-office/adminController/commande">
                            <div class="panel-body">
                                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Identifiant</th>
                                            <th>Date de Commande</th>
                                            <th>Client</th>
                                            <th>Medicament</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="odd gradeX" <?php foreach($commandes as $commande) { ?> >
                                            <td><?php echo $commande->id;?></td>
                                            <td><class="center"><?php echo $commande->dateCommande;?> </td>
                                            <td> <?php echo $commande->idClient;?> </td>
                                            <td> <?php echo $commande->idMedicament;?> </td>
                                    </form>
                                            <td>
                                                <button value="modifier">Modifier</button>
                                                <form action="<?php echo base_url();?>index.php/Back-office/adminController/deleteCommande" method="post">
                                                     <button value="supprimer">Supprimer</button>  
                                                </form>  
                                            </td>  
                                        </tr>
                                        
                                        <?php } ?>
                                        <form method="post" action="<?php echo base_url();?>index.php/Back-office/adminController/insertCommande">
                                            <td><input type="text" class="form-control" name="id"></td>
                                            <td><input type="text" class="form-control" name="dateCommande"></td>
                                            <td><input type="text" class="form-control" name="idClient"></td> 
                                            <td><input type="text" class="form-control" name="idMedicament"></td>
                                            <td><button value="ajouter">Ajouter</button></td>
                                        </form>     
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.panel-body -->
                        
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
      <?php $this->load->view('Back-office/footer'); ?>

    </body>

</html>
