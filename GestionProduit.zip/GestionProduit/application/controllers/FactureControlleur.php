<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FactureControlleur extends CI_Controller {

        

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
                $this->load->library('session');
                $this->load->helper('url');
                $this->load->library('user_agent');

                $this->load->model('ClientDAO');
                $this->load->model('ProduitDAO');
                $this->load->model('PanierDAO');
                date_default_timezone_set('Europe/Paris');
        }


        public function facturerPanier($totalAvantRemise){
                //getIdkil
                        $user = $this->session->userdata('pseudo');
                        $idkil = $user['idclient'];
                //getDateF
                        $dateActuel = date('d-m-Y');
                        $dateF = date("d-m-Y",strtotime($dateActuel.' +10 days'));
                        echo $dateF;
                //$this->FactureDAO->insererFacture($idkil,$totalAvantRemise,$dateF,$remiseFact,$remiseClient,$totalApaye,$payee,$arendre);        
        }
}