<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controlleur extends CI_Controller {

        

		 public function __construct()
        {
                parent::__construct();
                // Your own constructor code
                $this->load->library('session');
                $this->load->helper('url');
                $this->load->library('user_agent');

                $this->load->model('ClientDAO');
                $this->load->model('ProduitDAO');
                $this->load->model('PanierDAO');
        }



        public function login(){
        	$username = $this->input->post('login');
        	$mdp = $this->input->post('pass');
        	$user = $this->ClientDAO->getMember($username,$mdp);
        	if($user!=null){
        		$this->session->set_userdata('pseudo',$user);
                redirect($this->agent->referrer());
        	}
        	else{
        		$this->index();
        	}
        }




        public function deconnect(){
        	
        	$this->session->unset_userdata(array('pseudo'));
        	$this->session->sess_destroy();
        	$this->index();
        }





        public function getPro($limit,$offset){

        	$cat = $this->input->get('cat');
        	$scat = $this->input->get('scat');
        	$sscat = $this->input->get('sscat');
        	$feuil = $this->input->get('feuil');
        	if($cat==null)
        		$cat="%%";
        	if($scat==null)
        		$scat="%%";
        	if($sscat==null)
        		$sscat="%%";
        	if($feuil==null)
        		$feuil="%%";
        	//echo $cat."  ".$scat." ".$sscat." ".$feuil;
            //echo $limit."    ".$offset;
            $data = $this->ProduitDAO->getProduits($cat,$scat,$sscat,$feuil,$limit,$offset);
            $this->loadIndex($data,"acceuil");
        }



        public function dashBoard(){
            $this->load->view('Back-office/accueil');
        }

        public function index(){
            
            $data = $this->ProduitDAO->getProduits('%%','%%','%%','%%',100,0);
            $page = "acceuil";
            $this->loadIndex($data,$page);
        }





        public function loadIndex($dataProduit,$page){
            $user = $this->session->userdata('pseudo');
            $idkil = ($user==null) ? -1 : $user['idclient'];
            
            try{
                $idPan = $this->PanierDAO->getIdPanierNoRegister($idkil);
                $sizeOfPanier = $this->PanierDAO->getNbresProduitInPanier($idPan);
            }
            catch(Exception $e){
                $sizeOfPanier = "0";
            }

            $dataCat = $this->getCatAndChild();
        	$this->load->view('index1',array('cat'=>$dataCat,'data'=>$dataProduit,'page'=>$page,'panierSize'=>$sizeOfPanier));
        }





/**getPanierView et loadPanier(getPaniersByModel et ses details pour chacun,   get Panier actuelle)**/

        public function getInitialPanierView(){

            $this->loadPanier("%%","TOUS","panier");
        }

        public function getPanierView($idmodel,$nom){
            //.echo $model['idmodel']."/".$model['nom']
            $this->loadPanier($idmodel, $nom,"panier");
            }

       
        public function loadPanier($idmodel,$modelNom,$page){
            $user = $this->session->userdata('pseudo');
            $idkil = $user['idclient'];

            //get liste Modele du client qui a au moins un panier
            $model = $this->PanierDAO->getModele($idkil);
                //echo count($model);
            
            //get Paniers du model selectionné
            $paniersByModel = $this->PanierDAO->getPanierByModel($idmodel,$idkil);
                //echo "test ".count($paniersByModel);
                //pour chaque panier get listdetails panier
                    for($i=0;$i<count($paniersByModel);$i++){
                            
                        $paniersByModel[$i] = $this->getListDetail($paniersByModel[$i]);
                        //var_dump($paniersByModel[$i]);
                    }

            //get sizeOfPanier
            try{
                $pan = $this->PanierDAO->getPanierNoRegister($idkil);
                $sizeOfPanier = $this->PanierDAO->getNbresProduitInPanier($pan['idpanier']);
            }
            catch(Exception $e){
                $sizeOfPanier = "0";
            }

            //getPanierCourant avec ses details
                $pan = $this->getListDetail($pan);

            //getAllModel
                $allModel = $this->getAllModel();

            $this->load->view('index1',array('allModels'=>$allModel,'models'=>$model,'nomModelSelectionne'=>$modelNom,'listePaniers'=>$paniersByModel,'panierCourante'=>$pan,'page'=>$page,'panierSize'=>$sizeOfPanier));
        }


        

        public function registerPanier($idpanier){
            $nom = $this->input->get('name');
            $idmodel = $this->input->get('selectModelPanier');
            //echo $nom."   ".$model;
            $this->PanierDAO->registerPanier($idpanier,$nom,1,$idmodel);

            redirect($this->agent->referrer());
        }




        public function getListDetail($panier){
            //get details panier 
                //echo count($paniers);
           
                $panier['details'] = $this->PanierDAO->getDetailByPanier($panier['idpanier']);

                //control disponibilite pour chaque detail
                for($ii=0;$ii<count($panier['details']);$ii++){
                    if($panier['details'][$ii]['quantite'] > $panier['details'][$ii]['disponibilite'])
                           $panier['details'][$ii]['quantite'] = $panier['details'][$ii]['disponibilite'];
                }
                return $panier;
        }


        public function getCatAndChild(){
        	
        	$cat = $this->ProduitDAO->getCategorie();

        	
        	//foreach($cat as $c){
            for($i=0;$i<count($cat);$i++){
        		//echo "idcat ".$c['idcat'];
        		//$c['scat'] =   $this->ProduitDAO->getSousCategorie($c['idcat']);
        		$cat[$i]['scat'] =   $this->ProduitDAO->getSousCategorie($cat[$i]['idcat']);
                //foreach($c['scat'] as $sc){
                for($ii=0;$ii<count($cat[$i]['scat']);$ii++){
        			//echo "idscat ".$sc['idscat'];
        			//$sc['sscat'] = $this->ProduitDAO->getsSousCat($sc['idscat']);
                    $cat[$i]['scat'][$ii]['sscat'] = $this->ProduitDAO->getsSousCat($cat[$i]['scat'][$ii]['idscat']);
        			//var_dump($sc['sscat']);
        			//foreach($sc['sscat'] as $ssc){
                    for($iii=0;$iii<count($cat[$i]['scat'][$ii]['sscat']);$iii++){
                    	//echo "feuill ".$ssc['idsscat'];
        				//$ssc['feuil'] = $this->ProduitDAO->getsSousCat($ssc['idsscat']);
                        $cat[$i]['scat'][$ii]['sscat'][$iii]['feuil'] = $this->ProduitDAO->getFeuille($cat[$i]['scat'][$ii]['sscat'][$iii]['idsscat']);
        			}
        		}
        	}
        	return $cat;
 		}





        public function test($t){
            echo "riana";    
        }



        public function incrementDetail($iddetail,$idpan){
            $quant = $this->input->get('quantite');
            $this->PanierDAO->incrementQuantitePro($iddetail,$quant);
            /*majDatePanier*/
                            $this->PanierDAO->majDatePanier($idpan);
            redirect($this->agent->referrer());
        }

        
       
        public function getAllModel(){
            return $this->PanierDAO->getAllModel();
        }
        



        public function ajouterAuPanier($idkil){

            
            $idpro = $this->input->get('hiddenValue');
            $quantite = $this->input->get('quantite');
           
            /*ClientAunPanierEtat0 ?*/
                try{
                    $idPan = $this->PanierDAO->getIdPanierNoRegister($idkil);
                    
                }
                catch(Exception $e){
                    $this->PanierDAO->creerPanier($idkil);
                    $idPan = $this->PanierDAO->getIdPanierNoRegister($idkil);
                }

                /*le produit est deja dans le panier ?*/
                    try{
                        $idD = $this->PanierDAO->isProduitInPanier($idpro,$idPan);
                        $this->PanierDAO->incrementQuantitePro($idD,$quantite);
                    }
                    catch(Exception $e){
                        $this->PanierDAO->creerDetailPanier($idpro,$idPan,$quantite);
                        /*majDatePanier*/
                            $this->PanierDAO->majDatePanier($idPan);
                    }
                
                
               

                /*load view*/
                redirect($this->agent->referrer());
        }


        public function dropPanier($idpanier){
            $this->PanierDAO->setEtatPanier($idpanier,3);
             /*load view*/
                redirect($this->agent->referrer());
        }



        public function incrementDetailJs($iddetail,$idpan){
            $quant = $this->input->get('quantite');
            $this->PanierDAO->incrementQuantitePro($iddetail,$quant);
            /*majDatePanier*/
                            $this->PanierDAO->majDatePanier($idpan);
        }


        public function dropDetailJs($iddetail){
            $this->PanierDAO->dropDetail($iddetail);
        }

        public function viderPanier($idpanier){
            $this->PanierDAO->viderPanier($idpanier);
            /*load view*/
                redirect($this->agent->referrer());
        }


        public function usePanier($idpanierAutilise,$idpanierActuelle){

            //recuperer liste detail du panier a utiliser
                $details = $this->PanierDAO->getDetailPanierByIdPanier($idpanierAutilise);

                //inserer chaque detail dans le panier actuelle
                    foreach ($details as $d) {
                        $this->PanierDAO->creerDetailPanier($d['idproduit'],$idpanierActuelle,$d['quantite']);
                    }

                redirect($this->agent->referrer());

        }

        public function getInitialFactureView(){
            $this->load->view('fact');
        }
 }