<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

		 public function __construct()
        {
                parent::__construct();
                // Your own constructor code
                $this->load->library('session');
                $this->load->helper('url');
                $this->load->model('PanierDao');
        }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//echo "test";
		//echo $this->PanierDao->test();
		//

		/*if($this->session->userdata('pseudo')!=null){
			$data = $this->FonctionDAO->getProduits();
			$this->load->view('acceuil',array('page'=>'detailFacture','data'=>$data));
		}
		else{
			$rep = array('page'=>'facture');
		$this->load->view('acceuil',$rep);*/
		//$rep = array('page'=>'detailFacture');
		//$this->load->view('index1',$rep);
		//}
		$this->load->view('welcome_message.php');
		
	}
	public function andrana($pseudo=''){
		echo "Bonjour". $pseudo . '<br>';
		echo "Veloma" . $this->input->get('id');
		//$this->load->view('teste');
	}


	public function seConnecter(){
		$data = $this->FonctionDAO->getProduits();
		$username = $this->input->post('login');
		$mdp = $this->input->post('mdp');
		$kil = $this->FonctionDAO->isMember($username,$mdp);
		if($kil!=null){
			$this->session->set_userdata('pseudo',$kil);
			$this->load->view('acceuil',array('page'=>'detailFacture','data'=>$data));
		}
		else{
			$rep = array('page'=>'facture','eror'=>'incorrecte');
			$this->load->view('acceuil',$rep);
		}
	}

	public function ajoutPanier(){
		$kil = $this->session->userdata('pseudo');
		$bool = $this->FonctionDAO->aUnPanier($kil[0]['IDCLIENT']);
		if(!$bool)
		{
			$this->FonctionDAO->insererPanier($kil[0]['IDCLIENT'],100);
		}
		
	}

	public function seDeconnecter(){
		$this->session->unset_userdata(array('pseudo'));
		$this->session->sess_destroy();
	}

	public function getpage2(){
		echo "Veloma".$this->input->get('date');
		echo "Veloma".$this->input->get('client');
		$this->load->view('Back-office/commande');
	}

	public function test(){
		 

	}
	
	
}