-- phpMyAdmin SQL Dump
-- version 4.0.2
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mar 11 Décembre 2018 à 08:08
-- Version du serveur: 5.6.11-log
-- Version de PHP: 5.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `basefacturation`
--
CREATE DATABASE IF NOT EXISTS `basefacturation` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `basefacturation`;

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `IDCLIENT` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` char(250) NOT NULL,
  `PASS` char(250) NOT NULL,
  PRIMARY KEY (`IDCLIENT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `IDCAT` int(11) NOT NULL AUTO_INCREMENT,
  `NOMCAT` char(50) NOT NULL,
  PRIMARY KEY (`IDCAT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`IDCAT`, `NOMCAT`) VALUES
(1, 'Medicament'),
(2, 'Beaute_Soins');

-- --------------------------------------------------------

--
-- Structure de la table `categoriesouscat`
--

CREATE TABLE IF NOT EXISTS `categoriesouscat` (
  `IDCAT` int(11) NOT NULL,
  `IDSCAT` int(11) NOT NULL,
  PRIMARY KEY (`IDCAT`,`IDSCAT`),
  KEY `FK_CATEGORIESOUSCAT2` (`IDSCAT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `categoriesouscat`
--

INSERT INTO `categoriesouscat` (`IDCAT`, `IDSCAT`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `IDCLIENT` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(50) NOT NULL,
  `PASS` varchar(20) NOT NULL,
  `NUMCLIENT` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`IDCLIENT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`IDCLIENT`, `NOM`, `PASS`, `NUMCLIENT`) VALUES
(1, 'riana', 'riana', 'C001');

-- --------------------------------------------------------

--
-- Structure de la table `detailpanier`
--

CREATE TABLE IF NOT EXISTS `detailpanier` (
  `IDDETAIL` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `IDPANIER` int(11) unsigned NOT NULL,
  `IDPRODUIT` int(11) unsigned NOT NULL,
  `QUANTITE` tinyint(11) unsigned NOT NULL,
  PRIMARY KEY (`IDDETAIL`),
  KEY `IDPANIER` (`IDPANIER`),
  KEY `IDPRODUIT` (`IDPRODUIT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Contenu de la table `detailpanier`
--

INSERT INTO `detailpanier` (`IDDETAIL`, `IDPANIER`, `IDPRODUIT`, `QUANTITE`) VALUES
(1, 1, 1, 6),
(2, 1, 2, 5),
(8, 3, 3, 10),
(7, 2, 6, 8),
(12, 4, 1, 6),
(11, 4, 3, 10);

-- --------------------------------------------------------

--
-- Structure de la table `detailsfact`
--

CREATE TABLE IF NOT EXISTS `detailsfact` (
  `CODEPRO` varchar(10) NOT NULL,
  `IDDETAIL` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `PU` decimal(10,2) NOT NULL,
  `QUANTITE` tinyint(11) unsigned NOT NULL,
  `TOTALDETAIL` decimal(18,2) NOT NULL,
  `IDFACT` int(10) unsigned NOT NULL,
  `REMISE` tinyint(3) unsigned NOT NULL,
  `NOMPRO` varchar(25) NOT NULL,
  PRIMARY KEY (`IDDETAIL`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `detailsfact`
--

INSERT INTO `detailsfact` (`CODEPRO`, `IDDETAIL`, `PU`, `QUANTITE`, `TOTALDETAIL`, `IDFACT`, `REMISE`, `NOMPRO`) VALUES
('', 1, '0.00', 0, '0.00', 4000000, 255, '');

-- --------------------------------------------------------

--
-- Structure de la table `etat`
--

CREATE TABLE IF NOT EXISTS `etat` (
  `STATUS` int(11) NOT NULL,
  `ETAT` char(50) NOT NULL,
  PRIMARY KEY (`STATUS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `etat`
--

INSERT INTO `etat` (`STATUS`, `ETAT`) VALUES
(100, 'vien d etre creer'),
(200, 'validee'),
(300, 'livrer');

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE IF NOT EXISTS `facture` (
  `IDFACT` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `IDCLIENT` int(11) unsigned NOT NULL,
  `DATED` date NOT NULL,
  `NUMFACT` varchar(50) NOT NULL,
  `TOTALAVANTREMISE` decimal(18,2) NOT NULL,
  `DATEF` date NOT NULL,
  `REMISEFACTURE` tinyint(4) NOT NULL,
  `REMISECLIENT` tinyint(4) NOT NULL,
  `TOTALAPAYE` decimal(18,2) NOT NULL,
  `PAYEE` decimal(18,2) NOT NULL,
  `ARENDRE` decimal(18,2) NOT NULL,
  PRIMARY KEY (`IDFACT`),
  KEY `FK_CLIENTFACT` (`IDCLIENT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `facture`
--

INSERT INTO `facture` (`IDFACT`, `IDCLIENT`, `DATED`, `NUMFACT`, `TOTALAVANTREMISE`, `DATEF`, `REMISEFACTURE`, `REMISECLIENT`, `TOTALAPAYE`, `PAYEE`, `ARENDRE`) VALUES
(1, 0, '0000-00-00', 'ras', '0.00', '0000-00-00', 0, 0, '0.00', '0.00', '0.00'),
(3, 32, '2018-12-18', 'ras', '34.00', '2018-12-28', 3, 3, '234.00', '23.00', '325.00');

-- --------------------------------------------------------

--
-- Structure de la table `feuille`
--

CREATE TABLE IF NOT EXISTS `feuille` (
  `IDFEUIL` int(11) NOT NULL AUTO_INCREMENT,
  `NOMFEUIL` char(50) DEFAULT NULL,
  PRIMARY KEY (`IDFEUIL`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `feuille`
--

INSERT INTO `feuille` (`IDFEUIL`, `NOMFEUIL`) VALUES
(1, 'Bronchite'),
(2, 'Vitamine'),
(3, 'trouble de la vue'),
(4, 'irritation');

-- --------------------------------------------------------

--
-- Structure de la table `fideliteclient`
--

CREATE TABLE IF NOT EXISTS `fideliteclient` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IDCLIENT` int(10) unsigned NOT NULL,
  `CA` decimal(18,6) unsigned NOT NULL,
  `AVGJOURSRETARD` decimal(4,1) NOT NULL,
  `NBRERETARD` tinyint(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `IDIMAGE` int(11) NOT NULL,
  `IDPRO` int(11) NOT NULL,
  `NOMIMAGE` char(50) NOT NULL,
  PRIMARY KEY (`IDIMAGE`),
  KEY `IDPRO` (`IDPRO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `image`
--

INSERT INTO `image` (`IDIMAGE`, `IDPRO`, `NOMIMAGE`) VALUES
(1, 2, '1'),
(2, 3, '2'),
(3, 4, '3'),
(4, 5, '4'),
(5, 6, '5'),
(6, 7, '6'),
(7, 8, '7'),
(8, 9, '8');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `imageproduit`
--
CREATE TABLE IF NOT EXISTS `imageproduit` (
`idpro` int(11)
,`nompro` char(50)
,`prix` float(8,2)
,`codepro` char(50)
,`description` text
,`disponibilite` tinyint(4)
,`dosage` longtext
,`nomimage` char(50)
,`nomtype` char(50)
);
-- --------------------------------------------------------

--
-- Structure de la table `modelepanier`
--

CREATE TABLE IF NOT EXISTS `modelepanier` (
  `IDMODEL` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `NOM` varchar(20) NOT NULL,
  PRIMARY KEY (`IDMODEL`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `modelepanier`
--

INSERT INTO `modelepanier` (`IDMODEL`, `NOM`) VALUES
(1, 'pour_femme'),
(2, 'par_semaine'),
(3, 'pour_homme'),
(4, 'par_mois');

-- --------------------------------------------------------

--
-- Structure de la table `modepayement`
--

CREATE TABLE IF NOT EXISTS `modepayement` (
  `ID` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `NOM` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `modepayement`
--

INSERT INTO `modepayement` (`ID`, `NOM`) VALUES
(1, 'airtelMoney'),
(2, 'mvola'),
(3, 'orangeMoney');

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

CREATE TABLE IF NOT EXISTS `panier` (
  `IDPANIER` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `LADATE` date NOT NULL,
  `IDCLIENT` int(11) unsigned NOT NULL,
  `ETAT` tinyint(4) NOT NULL COMMENT 'enregistré =1 -- nonEnregistrer=0',
  `IDMODEL` tinyint(4) NOT NULL,
  `NOM` varchar(20) NOT NULL,
  PRIMARY KEY (`IDPANIER`),
  KEY `IDCLIENT` (`IDCLIENT`),
  KEY `STATUS` (`ETAT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `panier`
--

INSERT INTO `panier` (`IDPANIER`, `LADATE`, `IDCLIENT`, `ETAT`, `IDMODEL`, `NOM`) VALUES
(1, '2018-12-09', 1, 1, 1, 'panier mercredi'),
(2, '2018-12-09', 1, 3, 1, 'panier samedi'),
(3, '2018-12-09', 1, 1, 2, 'ravalo'),
(4, '2018-12-09', 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `payement`
--

CREATE TABLE IF NOT EXISTS `payement` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IDFACT` int(10) unsigned NOT NULL,
  `DATE` date NOT NULL,
  `MONTANT` decimal(18,2) NOT NULL,
  `IDMODEPAYEMENT` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE IF NOT EXISTS `produit` (
  `IDPRO` int(11) NOT NULL AUTO_INCREMENT,
  `CODEPRO` char(50) NOT NULL,
  `IDTYPE` int(11) NOT NULL,
  `NOMPRO` char(50) NOT NULL,
  `PRIX` float(8,2) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DOSAGE` longtext NOT NULL,
  `DISPONIBILITE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`IDPRO`),
  KEY `FK_PRODUITTYPE` (`IDTYPE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `produit`
--

INSERT INTO `produit` (`IDPRO`, `CODEPRO`, `IDTYPE`, `NOMPRO`, `PRIX`, `DESCRIPTION`, `DOSAGE`, `DISPONIBILITE`) VALUES
(2, 'P1', 2, 'Coquelusedal Nourrisons', 2.80, 'rien', '* 10', 10),
(3, 'P2', 3, 'ZymaD', 2.93, 'rien', '100ml', 5),
(4, 'P3', 4, 'Difrarel', 13.99, 'rien', '100 mg', 5),
(5, 'P4', 5, 'Dacryoserum', 2.11, 'rien', '* 20', 8),
(6, 'P5', 6, 'Vichy Dercos', 8.99, 'rien', '200 ml', 19),
(7, 'P6', 7, 'Color & soin 1N - Noir ebene', 7.46, 'rien', '60 ml', 13),
(8, 'P7', 8, 'Weleda Creme', 11.99, 'rien', '30 ml', 12),
(9, 'P8', 9, 'NoBacter Mousse', 10.88, 'rien', '2 * 150ml', 11);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `produitclass`
--
CREATE TABLE IF NOT EXISTS `produitclass` (
`nomimage` char(50)
,`idcat` int(11)
,`idscat` int(11)
,`idsscat` int(11)
,`idfeuil` int(11)
,`idpro` int(11)
,`codepro` char(50)
,`nompro` char(50)
,`prix` float(8,2)
,`description` text
,`dosage` longtext
,`disponibilite` tinyint(4)
,`nomtype` char(50)
);
-- --------------------------------------------------------

--
-- Structure de la table `produitrelation`
--

CREATE TABLE IF NOT EXISTS `produitrelation` (
  `IDPRO` int(11) NOT NULL,
  `IDCAT` int(11) NOT NULL,
  `IDSCAT` int(11) NOT NULL,
  `IDSSCAT` int(11) NOT NULL,
  `IDFEUIL` int(11) NOT NULL,
  PRIMARY KEY (`IDPRO`,`IDCAT`,`IDFEUIL`,`IDSSCAT`,`IDSCAT`),
  KEY `FK_PRODUITRELATION2` (`IDCAT`),
  KEY `FK_PRODUITRELATION3` (`IDFEUIL`),
  KEY `FK_PRODUITRELATION4` (`IDSSCAT`),
  KEY `FK_PRODUITRELATION5` (`IDSCAT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produitrelation`
--

INSERT INTO `produitrelation` (`IDPRO`, `IDCAT`, `IDSCAT`, `IDSSCAT`, `IDFEUIL`) VALUES
(2, 1, 1, 1, 1),
(3, 1, 1, 1, 2),
(4, 1, 1, 2, 3),
(5, 1, 1, 2, 4),
(6, 2, 3, 8, 0),
(7, 2, 3, 7, 0),
(8, 2, 4, 6, 0),
(9, 2, 4, 5, 0);

-- --------------------------------------------------------

--
-- Structure de la table `produitstock`
--

CREATE TABLE IF NOT EXISTS `produitstock` (
  `IDPRO` smallint(5) unsigned NOT NULL,
  `nbrStock` tinyint(3) unsigned NOT NULL,
  KEY `IDPRO` (`IDPRO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remiseclient`
--

CREATE TABLE IF NOT EXISTS `remiseclient` (
  `VALEUR` tinyint(4) NOT NULL,
  `minCA` int(11) NOT NULL,
  `maxCA` int(11) NOT NULL,
  `maxAvgJoursRetard` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remisefacture`
--

CREATE TABLE IF NOT EXISTS `remisefacture` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DATED` date NOT NULL,
  `DATEF` date NOT NULL,
  `VALUE` float NOT NULL,
  `CONDITION` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `remiseproduit`
--

CREATE TABLE IF NOT EXISTS `remiseproduit` (
  `ID` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `DATED` date NOT NULL,
  `DATEF` date NOT NULL,
  `IDPRO` tinyint(4) NOT NULL,
  `VALUE` tinyint(4) NOT NULL,
  `CONDITION` tinyint(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `sous2categoriefeuille`
--

CREATE TABLE IF NOT EXISTS `sous2categoriefeuille` (
  `IDSSCAT` int(11) NOT NULL,
  `IDFEUIL` int(11) NOT NULL,
  PRIMARY KEY (`IDSSCAT`,`IDFEUIL`),
  KEY `FK_SOUS2CATEGORIEFEUILLE2` (`IDFEUIL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sous2categoriefeuille`
--

INSERT INTO `sous2categoriefeuille` (`IDSSCAT`, `IDFEUIL`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `souscategorie`
--

CREATE TABLE IF NOT EXISTS `souscategorie` (
  `IDSCAT` int(11) NOT NULL AUTO_INCREMENT,
  `NOMSOUSCAT` char(50) DEFAULT NULL,
  PRIMARY KEY (`IDSCAT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `souscategorie`
--

INSERT INTO `souscategorie` (`IDSCAT`, `NOMSOUSCAT`) VALUES
(1, 'Par Symptome'),
(2, 'Par maladie'),
(3, 'Cheuveux'),
(4, 'Homme');

-- --------------------------------------------------------

--
-- Structure de la table `souscategoriesous2cat`
--

CREATE TABLE IF NOT EXISTS `souscategoriesous2cat` (
  `IDSCAT` int(11) NOT NULL,
  `IDSSCAT` int(11) NOT NULL,
  PRIMARY KEY (`IDSCAT`,`IDSSCAT`),
  KEY `FK_SOUSCATEGORIESOUS2CAT2` (`IDSSCAT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `souscategoriesous2cat`
--

INSERT INTO `souscategoriesous2cat` (`IDSCAT`, `IDSSCAT`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 7),
(3, 8),
(4, 5),
(4, 6);

-- --------------------------------------------------------

--
-- Structure de la table `soussouscategorie`
--

CREATE TABLE IF NOT EXISTS `soussouscategorie` (
  `IDSSCAT` int(11) NOT NULL AUTO_INCREMENT,
  `NOMSSCAT` char(250) NOT NULL,
  PRIMARY KEY (`IDSSCAT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `soussouscategorie`
--

INSERT INTO `soussouscategorie` (`IDSSCAT`, `NOMSSCAT`) VALUES
(1, 'bebe'),
(2, 'yeux'),
(3, 'angine'),
(4, 'sinusite'),
(5, 'rasage'),
(6, 'soin visage'),
(7, 'coloration'),
(8, 'shampoing');

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `IDTYPE` int(11) NOT NULL AUTO_INCREMENT,
  `NOMTYPE` char(50) NOT NULL,
  PRIMARY KEY (`IDTYPE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `type`
--

INSERT INTO `type` (`IDTYPE`, `NOMTYPE`) VALUES
(1, 'Pommade'),
(2, 'Suppositoire'),
(3, 'Solution buvable'),
(4, 'comprime'),
(5, 'unidose'),
(6, 'shampoing'),
(7, 'teinture'),
(8, 'creme'),
(9, 'mousse');

-- --------------------------------------------------------

--
-- Structure de la vue `imageproduit`
--
DROP TABLE IF EXISTS `imageproduit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `imageproduit` AS select `p`.`IDPRO` AS `idpro`,`p`.`NOMPRO` AS `nompro`,`p`.`PRIX` AS `prix`,`p`.`CODEPRO` AS `codepro`,`p`.`DESCRIPTION` AS `description`,`p`.`DISPONIBILITE` AS `disponibilite`,`p`.`DOSAGE` AS `dosage`,`i`.`NOMIMAGE` AS `nomimage`,`t`.`NOMTYPE` AS `nomtype` from ((`produit` `p` join `image` `i` on((`p`.`IDPRO` = `i`.`IDPRO`))) join `type` `t` on((`p`.`IDTYPE` = `t`.`IDTYPE`)));

-- --------------------------------------------------------

--
-- Structure de la vue `produitclass`
--
DROP TABLE IF EXISTS `produitclass`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `produitclass` AS select `i`.`NOMIMAGE` AS `nomimage`,`pr`.`IDCAT` AS `idcat`,`pr`.`IDSCAT` AS `idscat`,`pr`.`IDSSCAT` AS `idsscat`,`pr`.`IDFEUIL` AS `idfeuil`,`p`.`IDPRO` AS `idpro`,`p`.`CODEPRO` AS `codepro`,`p`.`NOMPRO` AS `nompro`,`p`.`PRIX` AS `prix`,`p`.`DESCRIPTION` AS `description`,`p`.`DOSAGE` AS `dosage`,`p`.`DISPONIBILITE` AS `disponibilite`,`t`.`NOMTYPE` AS `nomtype` from (((`produit` `p` join `type` `t` on((`p`.`IDTYPE` = `t`.`IDTYPE`))) join `produitrelation` `pr` on((`p`.`IDPRO` = `pr`.`IDPRO`))) join `image` `i` on((`p`.`IDPRO` = `i`.`IDPRO`))) WITH CASCADED CHECK OPTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
